﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LabsForm
{
    public partial class LabsForm : Form
    {
        int[,] matr ={{ 0,  1, -1,  4, -1,  -1, -1},
                      { 1,  0,  2, 3, 4, -1, -1},
                      {-1,  2,  0,  -1, 2, -1, -1},
                      { 4, 3,  -1,  0,  -1, -1, -1},
                      {-1, 4, 2,  -1,  0,  7, -1},
                      { -1, -1, -1, -1,  7,  0, 6},
                      { -1, -1, -1, -1,  -1,  6, 0},};
        int[,] matr_vesov = new int[7, 7];
        int[,] matr_putej = new int[7, 7];
        int i, j, k, n=7;
        public LabsForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           comboBox1.Text = "2";
           comboBox2.Text = "6";
           dataGridView1.RowCount = n;
           for (i = 0; i < n; i++)
           {
               for (j = 0+i; j < n; j++)
               {
                   matr_vesov[i, j] = matr_vesov[j, i] = matr[i, j];
                   if (matr[i, j] == -1)
                   {
                       dataGridView1[j + 1, i].Style.BackColor = dataGridView1[i + 1, j].Style.BackColor = System.Drawing.Color.Gray;
                       matr_putej[j, i] = matr_putej[i, j] = 0;
                   }
                   else
                   {
                       dataGridView1[j + 1, i].Value = dataGridView1[i + 1, j].Value = matr[i, j];
                       matr_putej[j, i] = matr_putej[i, j] = j;
                   }
               }
               dataGridView1[0, i].Style.BackColor = System.Drawing.Color.LightGray;
               dataGridView1[0, i].Value = i + 1;
           }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int begin = Convert.ToInt32(comboBox1.Text);
            int finish = Convert.ToInt32(comboBox2.Text);
            for (i = 0; i < n; i++)
            {
                for (j = 0; j < n; j++)
                    for (k = 0; k < n; k++)
                        if (i != j && matr_vesov[j, i] != -1 && i != k && matr_vesov[i, k] != -1 && (matr_vesov[j, k] == -1 || matr_vesov[j, k] > matr_vesov[j, i] + matr_vesov[i, k]))
                        {
                            matr_putej[j, k] = matr_putej[j, i];
                            matr_vesov[j, k] = matr_vesov[j, i] + matr_vesov[i, k];
                        }
                for (j = 0; j < n; j++)
                    if (matr_vesov[j, j] < 0)
                        break;
            }

            if (matr_vesov[begin - 1, finish - 1] != 0)
                label6.Text = "Наикратчайший путь из точки №" + begin + " в точку №" + finish + " равно " + matr_vesov[begin - 1, finish - 1];
            else label6.Text = "Вы выбрали одну и ту же точку...";
        }
    }
}
